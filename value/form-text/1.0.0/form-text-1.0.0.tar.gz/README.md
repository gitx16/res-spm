# form-text

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-form-text">
</div>
````

```javascript
seajs.use('form-text', function(formText) {

});
```

## Api

Here is some details.
