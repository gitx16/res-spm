define(function(require) {

  var formText = require('../src/form-text');

  describe('form-text', function() {

    it('normal usage', function() {

    });
  });

});
