# Demo

---

## Normal usage

````javascript
seajs.use('form-text', function(formText) {

});
````
