# History

---

## 1.0.0

`new` value/form-ckeditor First version.
