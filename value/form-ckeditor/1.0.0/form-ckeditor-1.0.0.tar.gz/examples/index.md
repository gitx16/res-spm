# Demo

---

## Normal usage

````javascript
seajs.use('form-ckeditor', function(formCkeditor) {

});
````
