# form-ckeditor

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-form-ckeditor">
</div>
````

```javascript
seajs.use('form-ckeditor', function(formCkeditor) {

});
```

## Api

Here is some details.
