define(function(require) {

  var formCkeditor = require('../src/form-ckeditor');

  describe('form-ckeditor', function() {

    it('normal usage', function() {

    });
  });

});
