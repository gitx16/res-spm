# Demo

---

## Normal usage

````javascript
seajs.use('base', function(base) {

});
````
