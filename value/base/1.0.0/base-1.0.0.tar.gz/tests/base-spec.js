define(function(require) {

  var base = require('../src/base');

  describe('base', function() {

    it('normal usage', function() {

    });
  });

});
