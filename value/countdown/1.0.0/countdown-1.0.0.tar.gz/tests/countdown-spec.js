define(function(require) {

  var countdown = require('../src/countdown');

  describe('countdown', function() {

    it('normal usage', function() {

    });
  });

});
