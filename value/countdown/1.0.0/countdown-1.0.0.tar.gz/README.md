# countdown

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-countdown">
</div>
````

```javascript
seajs.use('countdown', function(countdown) {

});
```

## Api

Here is some details.
