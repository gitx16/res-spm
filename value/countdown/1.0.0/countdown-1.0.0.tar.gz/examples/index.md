# Demo

---

## Normal usage

````javascript
seajs.use('countdown', function(countdown) {

});
````
