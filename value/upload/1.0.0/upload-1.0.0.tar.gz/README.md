# upload

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-upload">
</div>
````

```javascript
seajs.use('upload', function(upload) {

});
```

## Api

Here is some details.
