define(function(require) {

  var upload = require('../src/upload');

  describe('upload', function() {

    it('normal usage', function() {

    });
  });

});
