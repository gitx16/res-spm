# Demo

---

## Normal usage

````javascript
seajs.use('upload', function(upload) {

});
````
