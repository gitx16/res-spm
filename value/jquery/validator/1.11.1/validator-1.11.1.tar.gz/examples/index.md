# Demo

---

## Normal usage

````javascript
seajs.use('validator', function(validator) {

});
````
