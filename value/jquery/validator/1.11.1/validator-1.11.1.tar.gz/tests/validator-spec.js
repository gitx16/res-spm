define(function(require) {

  var validator = require('../src/validator');

  describe('validator', function() {

    it('normal usage', function() {

    });
  });

});
