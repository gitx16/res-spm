# Demo

---

## Normal usage

````javascript
seajs.use('autoNumeric', function(autoNumeric) {

});
````
