define(function(require) {

  var autoNumeric = require('../src/autoNumeric');

  describe('autoNumeric', function() {

    it('normal usage', function() {

    });
  });

});
