# autoNumeric

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-autoNumeric">
</div>
````

```javascript
seajs.use('autoNumeric', function(autoNumeric) {

});
```

## Api

Here is some details.
