# History

---

## 1.0.0

`new` value/autoNumeric First version.
