# pin

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="-pin">
</div>
````

```javascript
seajs.use('pin', function(pin) {

});
```

## Api

Here is some details.
