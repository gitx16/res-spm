# Demo

---

## Normal usage

````javascript
seajs.use('pin', function(pin) {

});
````
