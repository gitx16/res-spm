define(function(require) {

  var pin = require('../src/pin');

  describe('pin', function() {

    it('normal usage', function() {

    });
  });

});
