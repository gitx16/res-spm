# Demo

---

## Normal usage

````javascript
seajs.use('placeholder', function(placeholder) {

});
````
