# placeholder

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="jquery-placeholder">
</div>
````

```javascript
seajs.use('placeholder', function(placeholder) {

});
```

## Api

Here is some details.
