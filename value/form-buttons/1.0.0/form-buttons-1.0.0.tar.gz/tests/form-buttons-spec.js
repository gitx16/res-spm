define(function(require) {

  var formButtons = require('../src/form-buttons');

  describe('form-buttons', function() {

    it('normal usage', function() {

    });
  });

});
