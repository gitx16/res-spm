# Demo

---

## Normal usage

````javascript
seajs.use('form-buttons', function(formButtons) {

});
````
