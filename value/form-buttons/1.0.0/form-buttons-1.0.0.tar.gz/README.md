# form-buttons

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-form-buttons">
</div>
````

```javascript
seajs.use('form-buttons', function(formButtons) {

});
```

## Api

Here is some details.
