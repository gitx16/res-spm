# Demo

---

## Normal usage

````javascript
seajs.use('form-hidden', function(formHidden) {

});
````
