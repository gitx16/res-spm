define(function(require) {

  var formHidden = require('../src/form-hidden');

  describe('form-hidden', function() {

    it('normal usage', function() {

    });
  });

});
