# form-hidden

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-form-hidden">
</div>
````

```javascript
seajs.use('form-hidden', function(formHidden) {

});
```

## Api

Here is some details.
