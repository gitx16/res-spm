# datetimepicker

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-datetimepicker">
</div>
````

```javascript
seajs.use('datetimepicker', function(datetimepicker) {

});
```

## Api

Here is some details.
