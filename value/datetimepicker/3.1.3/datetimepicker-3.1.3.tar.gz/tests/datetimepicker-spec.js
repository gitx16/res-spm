define(function(require) {

  var datetimepicker = require('../src/datetimepicker');

  describe('datetimepicker', function() {

    it('normal usage', function() {

    });
  });

});
