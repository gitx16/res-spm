# Demo

---

## Normal usage

````javascript
seajs.use('datetimepicker', function(datetimepicker) {

});
````
