# Histroy

---

### 1.0.1

`tag:fixed` 修复被遮挡元素设置了z-index导致的问题 #2

### 1.0.0

发布稳定版本

### 0.9.3

`tag:fixed` 修复 `src="javascript:;"` 时的安全警报

### 0.9.2

发布第一个版本
