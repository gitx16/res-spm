# 设计模型

- order: 4

----

    inputValue  --->  model
                        ^
                        |
                      filter

## inputValue vs realValue
