define(function(require, exports, module) {
  var $ = require('$');
  var Widget = require('widget');

  var TestWidget = Widget.extend({

  });

  module.exports = TestWidget;

  module.exports.outerBoxClass = 'arale-text-widget-1_0_0';
});