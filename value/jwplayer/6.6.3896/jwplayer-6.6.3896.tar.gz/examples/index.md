# Demo

---

## Normal usage

````javascript
seajs.use('jwplayer', function(jwplayer) {

});
````
