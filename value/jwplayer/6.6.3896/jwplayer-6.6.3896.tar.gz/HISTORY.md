# History

---

## 6.6.3896

`new` value/jwplayer First version.
