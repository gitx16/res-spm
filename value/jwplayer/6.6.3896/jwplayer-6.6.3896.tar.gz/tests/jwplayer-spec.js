define(function(require) {

  var jwplayer = require('../src/jwplayer');

  describe('jwplayer', function() {

    it('normal usage', function() {

    });
  });

});
