# History

---

## 6.10.4906

`new` value/jwplayer First version.
