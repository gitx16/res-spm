# jwplayer

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-jwplayer">
</div>
````

```javascript
seajs.use('jwplayer', function(jwplayer) {

});
```

## Api

Here is some details.
