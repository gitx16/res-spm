# Demo

---

## Normal usage

````javascript
seajs.use('form-upload', function(formUpload) {

});
````
