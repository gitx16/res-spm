define(function(require) {

  var formUpload = require('../src/form-upload');

  describe('form-upload', function() {

    it('normal usage', function() {

    });
  });

});
