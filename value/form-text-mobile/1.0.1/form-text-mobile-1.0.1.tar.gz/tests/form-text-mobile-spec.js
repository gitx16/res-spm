define(function(require) {

  var formTextMobile = require('../src/form-text-mobile');

  describe('form-text-mobile', function() {

    it('normal usage', function() {

    });
  });

});
