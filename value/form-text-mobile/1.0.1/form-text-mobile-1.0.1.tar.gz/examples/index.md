# Demo

---

## Normal usage

````javascript
seajs.use('form-text-mobile', function(formTextMobile) {

});
````
