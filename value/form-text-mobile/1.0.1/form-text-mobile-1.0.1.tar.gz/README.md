# form-text-mobile

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-form-text-mobile">
</div>
````

```javascript
seajs.use('form-text-mobile', function(formTextMobile) {

});
```

## Api

Here is some details.
