# Demo

---

## Normal usage

````javascript
seajs.use('dialog', function(dialog) {

});
````
