define(function(require) {

  var dialog = require('../src/dialog');

  describe('dialog', function() {

    it('normal usage', function() {

    });
  });

});
