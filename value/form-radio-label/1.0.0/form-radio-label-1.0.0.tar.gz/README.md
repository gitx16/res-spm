# form-radio

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-form-radio">
</div>
````

```javascript
seajs.use('form-radio', function(formRadio) {

});
```

## Api

Here is some details.
