define(function(require) {

  var faskclick = require('../src/faskclick');

  describe('faskclick', function() {

    it('normal usage', function() {

    });
  });

});
