# faskclick

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-faskclick">
</div>
````

```javascript
seajs.use('faskclick', function(faskclick) {

});
```

## Api

Here is some details.
