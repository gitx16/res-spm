# Demo

---

## Normal usage

````javascript
seajs.use('faskclick', function(faskclick) {

});
````
