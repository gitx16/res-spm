# History

---

## 1.0.6

`new` value/faskclick First version.
