# Demo

---

## Normal usage

````javascript
seajs.use('form-text-date', function(formTextDate) {

});
````
