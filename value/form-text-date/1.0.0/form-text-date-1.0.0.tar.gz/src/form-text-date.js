define(function (require, exports, module) {
    var $ = require("$");
    require("datetimepicker");
    var template = require("./text-date.handlebars");
    var FormText = require("value-form-text");
    var FormTextDate =  FormText.extend({
        attrs:{
            template:template,
            emailTip:false,
            explain:""
        },
        setup: function () {
            var format = this.get("format")||'YYYY-MM-DD HH:mm:ss';
            var pickTime = this.get("pickTime")!==false;
            this.$("input").datetimepicker({
                pickTime:pickTime,
                lang:'zh-cn',
                format:format
            });
            FormTextDate.superclass.setup.call(this);
        }
    })
    module.exports = FormTextDate;
});
