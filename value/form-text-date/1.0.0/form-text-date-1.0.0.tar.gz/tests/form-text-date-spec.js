define(function(require) {

  var formTextDate = require('../src/form-text-date');

  describe('form-text-date', function() {

    it('normal usage', function() {

    });
  });

});
