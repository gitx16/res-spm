# form-text-date

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-form-text-date">
</div>
````

```javascript
seajs.use('form-text-date', function(formTextDate) {

});
```

## Api

Here is some details.
