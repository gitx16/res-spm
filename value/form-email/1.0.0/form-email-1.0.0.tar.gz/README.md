# form-email

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-form-email">
</div>
````

```javascript
seajs.use('form-email', function(formEmail) {

});
```

## Api

Here is some details.
