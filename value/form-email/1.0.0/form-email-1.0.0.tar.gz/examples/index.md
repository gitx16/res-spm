# Demo

---

## Normal usage

````javascript
seajs.use('form-email', function(formEmail) {

});
````
