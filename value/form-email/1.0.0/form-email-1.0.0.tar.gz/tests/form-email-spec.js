define(function(require) {

  var formEmail = require('../src/form-email');

  describe('form-email', function() {

    it('normal usage', function() {

    });
  });

});
