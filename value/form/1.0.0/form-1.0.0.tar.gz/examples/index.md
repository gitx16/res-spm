# Demo

---

## Normal usage

````javascript
seajs.use('form', function(form) {

});
````
