# form

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-form">
</div>
````

```javascript
seajs.use('form', function(form) {

});
```

## Api

Here is some details.
