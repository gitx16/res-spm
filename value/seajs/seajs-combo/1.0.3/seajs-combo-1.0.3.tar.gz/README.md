# seajs-combo

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="seajs-seajs-combo">
</div>
````

```javascript
seajs.use('seajs-combo', function(seajsCombo) {

});
```

## Api

Here is some details.
