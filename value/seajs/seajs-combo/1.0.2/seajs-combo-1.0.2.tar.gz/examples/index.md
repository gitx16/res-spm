# Demo

---

## Normal usage

````javascript
seajs.use('seajs-combo', function(seajsCombo) {

});
````
