define(function(require) {

  var seajsCombo = require('../src/seajs-combo');

  describe('seajs-combo', function() {

    it('normal usage', function() {

    });
  });

});
