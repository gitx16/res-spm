define('b2', ['b'], function(require, exports) {
  exports.name = require('b').name + '2'
});
