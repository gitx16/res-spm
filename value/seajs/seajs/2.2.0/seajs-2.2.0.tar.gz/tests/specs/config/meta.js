define([
  'alias',
  'base',
  'charset',
  'hasOwnProperty',
  'map',
  'paths',
  'preload',
  'vars'
])

