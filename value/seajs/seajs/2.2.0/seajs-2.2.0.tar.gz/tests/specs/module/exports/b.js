define(function(require, exports, mod) {

  mod.exports = { foo : 'b' }

});
