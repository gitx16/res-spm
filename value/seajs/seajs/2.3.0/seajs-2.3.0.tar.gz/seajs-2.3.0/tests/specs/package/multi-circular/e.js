define(function() {
  return 'e';
})