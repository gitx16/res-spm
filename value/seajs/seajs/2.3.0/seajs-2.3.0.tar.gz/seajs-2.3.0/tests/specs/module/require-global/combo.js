define('combo-a', ['combo-b', 'combo-c'], { name: 'a' });
define('combo-b', [], { name: 'b' });
define('combo-c', [], { name: 'c' });
