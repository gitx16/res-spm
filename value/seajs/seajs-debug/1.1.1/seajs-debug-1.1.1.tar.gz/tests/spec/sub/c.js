define({ name: 'c' });
