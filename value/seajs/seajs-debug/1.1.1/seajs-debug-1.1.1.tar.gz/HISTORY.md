# History

---

## 1.1.0

`tag:improved`  重构, 添加 1) 解 combo, 2) 切换源码/压缩代码显示, 3) 清除缓存, 4) 载入 seajs-log, 5) 载入 seajs-health, 6) 定制映射
    6) 可自定义 config

## 1.0.0

`tag:new` 初始化