seajs-log
===========

A Sea.js plugin to provide log function


> seajs-log@1.0.1+ is compatible with seajs@2.2.0+ !


Install
-------

Install with spm:

    $ spm install seajs/seajs-log


Usage
-----

```html
<script src="path/to/sea.js"></script>
<script src="path/to/seajs-log.js"></script>

<script>

  seajs.log('hello world')

</script>

```

For more details please visit [中文文档](https://github.com/seajs/seajs-log/issues/1)
