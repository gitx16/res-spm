define(function(require) {

  var formCheckbox = require('../src/form-checkbox');

  describe('form-checkbox', function() {

    it('normal usage', function() {

    });
  });

});
