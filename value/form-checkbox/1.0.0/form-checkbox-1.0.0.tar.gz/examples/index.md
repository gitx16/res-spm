# Demo

---

## Normal usage

````javascript
seajs.use('form-checkbox', function(formCheckbox) {

});
````
