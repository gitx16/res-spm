# Demo

---

## Normal usage

````javascript
seajs.use('form-radio', function(formRadio) {

});
````
