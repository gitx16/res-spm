define(function(require) {

  var formRadio = require('../src/form-radio');

  describe('form-radio', function() {

    it('normal usage', function() {

    });
  });

});
