define(function(require) {

  var datasource = require('../src/datasource');

  describe('datasource', function() {

    it('normal usage', function() {

    });
  });

});
