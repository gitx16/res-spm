# Demo

---

## Normal usage

````javascript
seajs.use('datasource', function(datasource) {

});
````
