# datasource

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-datasource">
</div>
````

```javascript
seajs.use('datasource', function(datasource) {

});
```

## Api

Here is some details.
