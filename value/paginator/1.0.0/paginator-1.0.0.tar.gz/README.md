# paginator

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-paginator">
</div>
````

```javascript
seajs.use('paginator', function(paginator) {

});
```

## Api

Here is some details.
