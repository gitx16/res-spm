# Demo

---

## Normal usage

````javascript
seajs.use('paginator', function(paginator) {

});
````
