define(function(require) {

  var paginator = require('../src/paginator');

  describe('paginator', function() {

    it('normal usage', function() {

    });
  });

});
