# History

---

## 1.0.0

`new` value/paginator First version.
