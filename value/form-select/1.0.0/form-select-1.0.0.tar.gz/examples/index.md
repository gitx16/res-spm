# Demo

---

## Normal usage

````javascript
seajs.use('form-select', function(formSelect) {

});
````
