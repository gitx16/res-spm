# form-select

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-form-select">
</div>
````

```javascript
seajs.use('form-select', function(formSelect) {

});
```

## Api

Here is some details.
