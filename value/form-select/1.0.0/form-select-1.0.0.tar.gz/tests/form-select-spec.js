define(function(require) {

  var formSelect = require('../src/form-select');

  describe('form-select', function() {

    it('normal usage', function() {

    });
  });

});
