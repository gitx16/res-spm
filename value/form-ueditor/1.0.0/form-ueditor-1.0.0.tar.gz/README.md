# form-ueditor

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-form-ueditor">
</div>
````

```javascript
seajs.use('form-ueditor', function(formUeditor) {

});
```

## Api

Here is some details.
