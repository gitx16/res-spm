# Demo

---

## Normal usage

````javascript
seajs.use('form-ueditor', function(formUeditor) {

});
````
