define(function(require) {

  var formUeditor = require('../src/form-ueditor');

  describe('form-ueditor', function() {

    it('normal usage', function() {

    });
  });

});
