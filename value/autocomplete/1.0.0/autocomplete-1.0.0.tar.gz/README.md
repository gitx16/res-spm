# autocomplete

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="value-autocomplete">
</div>
````

```javascript
seajs.use('autocomplete', function(autocomplete) {

});
```

## Api

Here is some details.
