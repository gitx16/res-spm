# Demo

---

## Normal usage

````javascript
seajs.use('autocomplete', function(autocomplete) {

});
````
