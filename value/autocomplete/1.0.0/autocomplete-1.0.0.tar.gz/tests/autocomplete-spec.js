define(function(require) {

  var autocomplete = require('../src/autocomplete');

  describe('autocomplete', function() {

    it('normal usage', function() {

    });
  });

});
