define(function(require) {

  var placeholder = require('../src/placeholder');

  describe('placeholder', function() {

    it('normal usage', function() {

    });
  });

});
