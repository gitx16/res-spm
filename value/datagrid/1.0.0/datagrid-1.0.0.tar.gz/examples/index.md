# Demo

---

## Normal usage

````javascript
seajs.use('datagrid', function(datagrid) {

});
````
