define(function(require) {

  var marionette = require('../src/marionette');

  describe('marionette', function() {

    it('normal usage', function() {

    });
  });

});
