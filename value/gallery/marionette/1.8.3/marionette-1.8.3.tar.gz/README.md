# marionette

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="gallery-marionette">
</div>
````

```javascript
seajs.use('marionette', function(marionette) {

});
```

## Api

Here is some details.
