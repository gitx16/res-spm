# Demo

---

## Normal usage

````javascript
seajs.use('marionette', function(marionette) {

});
````
