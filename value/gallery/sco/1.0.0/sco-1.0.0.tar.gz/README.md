# sco

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="gallery-sco">
</div>
````

```javascript
seajs.use('sco', function(sco) {

});
```

## Api

Here is some details.
