# Demo

---

## Normal usage

````javascript
seajs.use('sco', function(sco) {

});
````
