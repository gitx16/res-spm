define(function(require) {

  var sco = require('../src/sco');

  describe('sco', function() {

    it('normal usage', function() {

    });
  });

});
