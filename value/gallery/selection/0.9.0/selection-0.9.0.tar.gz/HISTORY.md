# History of Selection.js

----------------

## 0.9.0

`tag:new` make it a CMD.

`tag:new` it works.
