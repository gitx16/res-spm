define({ name: 'x' })
