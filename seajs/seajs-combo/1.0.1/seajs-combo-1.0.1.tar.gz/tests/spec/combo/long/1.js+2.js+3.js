define('long/1', [], { name: '1' })
define('long/2', [], { name: '2' })
define('long/3', [], { name: '3' })
