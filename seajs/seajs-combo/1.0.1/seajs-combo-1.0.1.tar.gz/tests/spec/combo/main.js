
seajs.config({
  base: "./combo/",
  test: true,
  preload: ["../../dist/seajs-combo-debug"]
})

seajs.use("init")

