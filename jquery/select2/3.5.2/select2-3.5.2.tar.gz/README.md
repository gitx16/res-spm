# select2

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="jquery-select2">
</div>
````

```javascript
seajs.use('select2', function(select2) {

});
```

## Api

Here is some details.
