define(function(require) {

  var select2 = require('../src/select2');

  describe('select2', function() {

    it('normal usage', function() {

    });
  });

});
