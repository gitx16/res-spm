# History

---

## 3.5.2

`new` jquery/select2 First version.
