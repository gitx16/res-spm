# Demo

---

## Normal usage

````javascript
seajs.use('select2', function(select2) {

});
````
