# validator

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="jquery-validator">
</div>
````

```javascript
seajs.use('validator', function(validator) {

});
```

## Api

Here is some details.
