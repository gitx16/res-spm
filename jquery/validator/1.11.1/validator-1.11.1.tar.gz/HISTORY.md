# History

---

## 1.11.1

`new` jquery/validator First version.
