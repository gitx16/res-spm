# reqSelector

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="jquery-reqSelector">
</div>
````

```javascript
seajs.use('reqSelector', function(reqSelector) {

});
```

## Api

Here is some details.
