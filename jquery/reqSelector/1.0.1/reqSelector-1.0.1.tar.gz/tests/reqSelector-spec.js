define(function(require) {

  var reqSelector = require('../src/reqSelector');

  describe('reqSelector', function() {

    it('normal usage', function() {

    });
  });

});
