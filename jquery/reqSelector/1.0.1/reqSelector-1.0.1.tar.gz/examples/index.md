# Demo

---

## Normal usage

````javascript
seajs.use('reqSelector', function(reqSelector) {

});
````
