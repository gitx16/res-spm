# 特殊情况

- order: 3

---

<style>

body {
    //overflow: hidden;
}
#c {
    height: 400px;
    width: 400px;
    overflow: auto;
    background: gray;
}
#c #inner {
    height: 400px;
    width: 400px;
}
</style>


<div id="c">
    <div id="inner"></div>
</div>

<script>
seajs.use(['overlay', '$'], function(Overlay, $) {
    var o = new Overlay({
        template: "<div>目标元素1</div>",
        parentNode: '#c',
        style: {
            color: '#fff'
        },
        width: 200,
        height: 200,
        align: {
            selfXY: ['50%', '50%'],
            baseElement: '#c',
            baseXY: ['50%', '50%']
        }
    });
    o.show();
    o.set('style', {
        backgroundColor: '#f53379'
    });


    var elemOffset = o.element.offset(),
        parentOffset = $("#c").offset();

    console.log(elemOffset.top - parentOffset.top, elemOffset.left - parentOffset.left);



    var p = new Overlay({
        template: "<div>目标元素2</div>",
        style: {
            background: 'rgb(143, 10, 58)'
        },
        width: 200,
        height: 200,
        align: {
            selfXY: ['50%', '50%'],
            baseXY: ['50%', '50%']
        }
    });
    p.show();


    var pOffset = p.element.offset();

setTimeout(function() {

    var winWidth = $(window).outerWidth(),
        winHeight = $(window).outerHeight();

    console.log(pOffset.top, winHeight/2 - 100, pOffset.left, winWidth/2 - 100, winWidth);

}, 1000);

});
</script>

