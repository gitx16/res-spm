# History

---

## 1.1.0

`tag:changed` [#5](https://github.com/aralejs/events/issues/5) trigger 返回值变化。

## 1.0.0

正式版