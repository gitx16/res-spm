# History

---

## 0.9.1

`tag:fixed` #3 修复 template 编译后 renderPartial 渲染出错的问题

## 0.9.0

`tag:new` 第一个版本，从 widget 迁移出来