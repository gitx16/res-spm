# History

---

## 1.1.1

`tag:fixed` [#22](https://github.com/aralejs/base/issues/22) 修复 isEmptyObject 在 <= IE8 下的 bug

## 1.1.0

`tag:fixed` [#19](https://github.com/aralejs/base/issues/19) 修复 isPlainObject 的 bug

`tag:new` [#5](https://github.com/aralejs/base/issues/5) before 回调能阻止函数执行

`tag:improved` [#17](https://github.com/aralejs/base/issues/17) attribute 性能优化

`tag:improved` [#13](https://github.com/aralejs/base/pull/13) set 方法增加 override 属性

`tag:improved` [#16](https://github.com/aralejs/base/issues/16) after 回调传入原方法的参数

`tag:improved` [#14](https://github.com/aralejs/base/issues/14) 简化 initAttr，放到 widget 处理

`tag:improved` [#6](https://github.com/aralejs/base/issues/6) base 内部代码调整

`tag:improved` [aralejs/widget#50](https://github.com/aralejs/widget/issues/50) destroy 只调用一次

## 1.0.0

正式版本