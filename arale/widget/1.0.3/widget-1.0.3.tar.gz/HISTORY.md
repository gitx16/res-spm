# 历史记录

---


## 1.0.3

`tag:improved` [28](https://github.com/aralejs/widget/issues/28)Templatable 增加 cache，编译过后的模板不再编译，提高创建实例对象的性能。