# bootstrap

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="gallery-bootstrap">
</div>
````

```javascript
seajs.use('bootstrap', function(bootstrap) {

});
```

## Api

Here is some details.
