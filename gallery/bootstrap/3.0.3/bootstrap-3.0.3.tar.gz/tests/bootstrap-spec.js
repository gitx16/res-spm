define(function(require) {

  var bootstrap = require('../src/bootstrap');

  describe('bootstrap', function() {

    it('normal usage', function() {

    });
  });

});
