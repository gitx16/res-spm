# Demo

---

## Normal usage

````javascript
seajs.use('bootstrap', function(bootstrap) {

});
````
