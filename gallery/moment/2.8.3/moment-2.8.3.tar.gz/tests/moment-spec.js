define(function(require) {

  var moment = require('../src/moment');

  describe('moment', function() {

    it('normal usage', function() {

    });
  });

});
