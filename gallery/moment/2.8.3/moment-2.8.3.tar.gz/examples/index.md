# Demo

---

## Normal usage

````javascript
seajs.use('moment', function(moment) {

});
````
