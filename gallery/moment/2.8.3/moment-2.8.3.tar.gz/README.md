# moment

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="gallery-moment">
</div>
````

```javascript
seajs.use('moment', function(moment) {

});
```

## Api

Here is some details.
