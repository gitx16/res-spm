define(function (require, exports, module) {
    var moment = require('./moment');
    require('./locale/zh-cn');
    return moment;
});