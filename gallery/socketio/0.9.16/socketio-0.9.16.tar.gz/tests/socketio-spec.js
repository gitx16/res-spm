define(function(require) {

  var socketio = require('../src/socketio');

  describe('socketio', function() {

    it('normal usage', function() {

    });
  });

});
