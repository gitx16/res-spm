# socketio

---

A nice CMD module.

---

## Usage

It is very easy to use this module.

````html
<div class="gallery-socketio">
</div>
````

```javascript
seajs.use('socketio', function(socketio) {

});
```

## Api

Here is some details.
