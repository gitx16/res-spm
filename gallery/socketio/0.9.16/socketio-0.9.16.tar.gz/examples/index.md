# Demo

---

## Normal usage

````javascript
seajs.use('socketio', function(socketio) {

});
````
